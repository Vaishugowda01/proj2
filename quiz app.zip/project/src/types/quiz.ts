export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
}

export interface QuizState {
  currentQuestionIndex: number;
  score: number;
  timeRemaining: number;
  isQuizComplete: boolean;
  userAnswers: number[];
}