import React from 'react';
import { Question } from '../types/quiz';
import { CheckCircle, XCircle } from 'lucide-react';

interface ResultsProps {
  questions: Question[];
  userAnswers: number[];
  score: number;
  onRestart: () => void;
}

export const Results: React.FC<ResultsProps> = ({
  questions,
  userAnswers,
  score,
  onRestart,
}) => {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800">Quiz Complete!</h2>
        <p className="text-xl mt-2">
          Your score: {score} out of {questions.length}
        </p>
      </div>

      <div className="space-y-4">
        {questions.map((question, index) => (
          <div key={index} className="bg-white p-4 rounded-lg shadow">
            <div className="flex items-start gap-2">
              {userAnswers[index] === question.correctAnswer ? (
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
              ) : (
                <XCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-1" />
              )}
              <div>
                <p className="font-medium text-gray-800">{question.question}</p>
                <p className="text-sm text-gray-600 mt-1">
                  Correct answer: {question.options[question.correctAnswer]}
                </p>
                {userAnswers[index] !== question.correctAnswer && (
                  <p className="text-sm text-red-500 mt-1">
                    Your answer: {question.options[userAnswers[index]]}
                  </p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={onRestart}
        className="w-full py-3 px-4 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
      >
        Try Again
      </button>
    </div>
  );
};