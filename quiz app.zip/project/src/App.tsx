import React, { useState, useEffect } from 'react';
import { Brain } from 'lucide-react';
import { questions } from './data/questions';
import { Timer } from './components/Timer';
import { Question } from './components/Question';
import { Results } from './components/Results';
import { QuizState } from './types/quiz';

const QUIZ_TIME = 60; // 60 seconds per question

function App() {
  const [quizState, setQuizState] = useState<QuizState>({
    currentQuestionIndex: 0,
    score: 0,
    timeRemaining: questions.length * QUIZ_TIME,
    isQuizComplete: false,
    userAnswers: Array(questions.length).fill(-1),
  });

  useEffect(() => {
    if (quizState.timeRemaining <= 0) {
      setQuizState(prev => ({ ...prev, isQuizComplete: true }));
      return;
    }

    if (quizState.isQuizComplete) return;

    const timer = setInterval(() => {
      setQuizState(prev => ({
        ...prev,
        timeRemaining: prev.timeRemaining - 1,
      }));
    }, 1000);

    return () => clearInterval(timer);
  }, [quizState.timeRemaining, quizState.isQuizComplete]);

  const handleAnswerSelect = (answerIndex: number) => {
    setQuizState(prev => {
      const newUserAnswers = [...prev.userAnswers];
      newUserAnswers[prev.currentQuestionIndex] = answerIndex;

      const isLastQuestion = prev.currentQuestionIndex === questions.length - 1;
      const newScore = answerIndex === questions[prev.currentQuestionIndex].correctAnswer
        ? prev.score + 1
        : prev.score;

      return {
        ...prev,
        userAnswers: newUserAnswers,
        score: newScore,
        currentQuestionIndex: isLastQuestion ? prev.currentQuestionIndex : prev.currentQuestionIndex + 1,
        isQuizComplete: isLastQuestion,
      };
    });
  };

  const handleRestart = () => {
    setQuizState({
      currentQuestionIndex: 0,
      score: 0,
      timeRemaining: questions.length * QUIZ_TIME,
      isQuizComplete: false,
      userAnswers: Array(questions.length).fill(-1),
    });
  };

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Brain className="w-8 h-8 text-blue-500" />
              <h1 className="text-2xl font-bold text-gray-800">Quiz Time</h1>
            </div>
            <Timer timeRemaining={quizState.timeRemaining} />
          </div>

          <div className="h-2 bg-gray-200 rounded-full">
            <div
              className="h-2 bg-blue-500 rounded-full transition-all duration-300"
              style={{
                width: `${((quizState.currentQuestionIndex + 1) / questions.length) * 100}%`,
              }}
            />
          </div>

          {!quizState.isQuizComplete ? (
            <>
              <div className="text-sm text-gray-600">
                Question {quizState.currentQuestionIndex + 1} of {questions.length}
              </div>
              <Question
                question={questions[quizState.currentQuestionIndex]}
                selectedAnswer={quizState.userAnswers[quizState.currentQuestionIndex]}
                onSelectAnswer={handleAnswerSelect}
              />
            </>
          ) : (
            <Results
              questions={questions}
              userAnswers={quizState.userAnswers}
              score={quizState.score}
              onRestart={handleRestart}
            />
          )}
        </div>
      </div>
    </div>
  );
}

export default App;